import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;
import java.util.Vector;

public class WaterwayProgram {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Vector<Ship> shipsVector = new Vector<>();
        Stack<Ship> shipsStack = new Stack<>();
        Queue<Ship> shipsQueue = new LinkedList<>();

        try {
            for (int i = 0; i < 2; i++) {
                System.out.println("Enter details for CruiseLineShip " + (i + 1) + ":");
                System.out.print("Passenger Name: ");
                String shipName = scanner.next();
                System.out.print("Ship length (in meters): ");
                double shipLength = scanner.nextDouble();
                scanner.nextLine();
                System.out.print("Cruise Type: ");
                String cruiseType = scanner.nextLine();
                System.out.print("Passenger capacity: ");
                int passengerCapacity = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Cruise ship ID: ");
                int cruiseShipID = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Load capacity: ");
                int loadCapacity = scanner.nextInt();
                scanner.nextLine();

                CruiseLineShip cruiseLineShip = new CruiseLineShip(shipName, shipLength, cruiseType,
                        passengerCapacity, cruiseShipID, loadCapacity);

                shipsVector.add(cruiseLineShip);
                shipsStack.push(cruiseLineShip);
                shipsQueue.offer(cruiseLineShip);
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            System.out.println("----- Displaying Ships using Vector -----");
            for (Ship ship : shipsVector) {
                ship.displayDetails();
                System.out.println("-------------------------");
            }

            System.out.println("----- Displaying Ships using Stack -----");
            while (!shipsStack.isEmpty()) {
                Ship ship = shipsStack.pop();
                ship.displayDetails();
                System.out.println("-------------------------");
            }

            System.out.println("----- Displaying Ships using Queue -----");
            while (!shipsQueue.isEmpty()) {
                Ship ship = shipsQueue.poll();
                ship.displayDetails();
                System.out.println("-------------------------");
            }

            System.out.println("----- Searching for 'test' in Ships -----");
            for (Ship ship : shipsVector) {
                if (ship.getPassengerName().equals("test")) {
                    System.out.println("Found in Vector");
                }
            }

            scanner.close();
        }
    }
}

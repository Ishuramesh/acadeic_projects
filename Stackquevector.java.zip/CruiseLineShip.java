class CruiseLineShip extends Ship {
    private int cruiseShipID;
    private int loadCapcity;

    //constructor
    public CruiseLineShip(String passengerName, double shipLength, String cruiseType, int Passengercapacity, int cruiseShipID, int loadCapcity) {
        super(passengerName, shipLength, cruiseType, Passengercapacity);
        this.cruiseShipID = cruiseShipID;
        this.loadCapcity = loadCapcity;
    }
    @Override
    void displaycruiseshipID() {
        System.out.println("Cruise Ship ID: " + cruiseShipID);

    }

    public void displayDetails () {
        super.displayDetails();
        this.displaycruiseshipID();
        System.out.println("Cruise Ship ID: " + cruiseShipID);
        System.out.println("load Capcity: " + loadCapcity);
    }

}



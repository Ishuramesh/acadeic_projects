package ThreadsEvenOdd;

public class PrintEvenNumbers extends Thread {
    private int n;

    public PrintEvenNumbers(int n) {
        this.n = n;
    }

    @Override
    public void run() {
        try {
            for (int i = 0; i <= n; i++) {
                if (i % 2 == 0) {
                    System.out.print(i + " ");
                    Thread.sleep(100);
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

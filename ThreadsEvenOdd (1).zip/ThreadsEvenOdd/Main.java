package ThreadsEvenOdd;

public class Main {
    public static void main(String[] args) {
        PrintEvenNumbers printEvenNumbers = new PrintEvenNumbers(20);
        PrintOddNumbers printOddNumbers = new PrintOddNumbers(20);

        printEvenNumbers.start();
        printOddNumbers.start();
    }
}

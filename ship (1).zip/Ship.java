class Ship {
    private String shipName;
    private double shipLength;
    private String engineType;
    private double range;


    public Ship (String shipName, double shipLength, String engineType, double range) {
        this.shipName = shipName;
        this.shipLength = shipLength;
        this.engineType = engineType;
        this.range = range;

    }

    public String getShipName() {
        return shipName;
    }

    public void displayDetails() {
        System.out.println(getShipName());
        System.out.println("Length: " + shipLength + " meters");
        System.out.println("Engine Type: " + engineType);
        System.out.println("Range: " + range);

    }
}

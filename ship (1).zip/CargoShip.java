class CargoShip extends Ship {
    private int cargoShipID;
    private int loadCapcity;

    //constructor
    public CargoShip(String shipName, double shipLength, String engineType, double range, int cargoShipID, int loadCapcity) {
        super(shipName, shipLength, engineType, range);
        this.cargoShipID = cargoShipID;
        this.loadCapcity = loadCapcity;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Cargo Ship ID: " + cargoShipID );
        System.out.println("load Capcity: " + loadCapcity);
    }
}

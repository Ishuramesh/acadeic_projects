import java.util.ArrayList;
import java.util.Scanner;

public class WaterwayProgram {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Ship> ships = new ArrayList<>();

        for (int i = 0; i < 2; i++) {
            System.out.println("Enter details for CargoShip " + (i + 1) + ":");
            System.out.print("Ship Name: ");
            String shipName = scanner.nextLine();
            System.out.print("Ship Length (in meters): ");
            double shipLength = scanner.nextDouble();
            scanner.nextLine();
            System.out.print("Engine Type: ");
            String engineType = scanner.nextLine();
            System.out.print("Range (in meters): ");
            double range = scanner.nextInt();
            scanner.nextLine(); //
            System.out.print("cargoShipID ");
            int cargoShipID = scanner.nextInt();
            scanner.nextLine(); //
            System.out.print("loadCapcity ");
            int loadCapcity = scanner.nextInt();
            scanner.nextLine(); //

            ships.add(new CargoShip(shipName, shipLength, engineType, range, cargoShipID, loadCapcity));

            }
        for (Ship ship : ships) {
            ship.displayDetails();
            System.out.println("-------------------------");
        }
        System.out.println("-----Search------");
        for (Ship ship : ships) {
            if(ship.getShipName().equals("test")){
                System.out.println("Found");
            }
        }
        scanner.close();
    }
}

class CruiseLineShip extends Ship {
    private int cruiseShipID;
    private int loadCapcity;

    // Constructor
    public CruiseLineShip(String passengerName, double shipLength, String cruiseType, int passengercapacity, int cruiseShipID, int loadCapcity) {
        super(passengerName, shipLength, cruiseType, passengercapacity);
        this.cruiseShipID = cruiseShipID;
        this.loadCapcity = loadCapcity;
    }

    @Override
    void displaycruiseshipID() {
        System.out.println("Cruise Ship ID: " + cruiseShipID);
    }

    public void displayDetails() {
        // Call  superclass method
        super.displayDetails();
        // Call overridden method in this class
        this.displaycruiseshipID();
        System.out.println("Cruise Ship ID: " + cruiseShipID);
        System.out.println("Load Capacity: " + loadCapcity);
    }
}

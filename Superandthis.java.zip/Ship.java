abstract class Ship {
    abstract void displaycruiseshipID();

    private String passengerName;
    private double shipLength;
    private String cruiseType;
    private int Passengercapacity;


    public Ship(String passengerName, double shipLength, String cruiseType, int Passengercapacity) {
        this.passengerName = passengerName;
        this.shipLength = shipLength;
        this.cruiseType = cruiseType;
        this.Passengercapacity = Passengercapacity;

    }

    public String getPassengerName() {
        return passengerName;
    }

    public void displayDetails() {
        System.out.println(getPassengerName());
        System.out.println("Length: " + shipLength + " meters");
        System.out.println("cruise Type: " + cruiseType);
        System.out.println("passenger capacity: " + Passengercapacity);

    }
}



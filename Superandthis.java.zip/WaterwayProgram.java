import java.util.ArrayList;
import java.util.Scanner;

public class WaterwayProgram {
    public static void main(String[] args) {
        Scanner Scanner = new Scanner(System.in);
        ArrayList<Ship> ships = new ArrayList<>();

        try {
            for (int i = 0; i < 2; i++) {
                System.out.println("Enter details for CruiseLineShip " + (i + 1) + ":");
                System.out.print("Passenger Name: ");
                java.lang.String shipName = Scanner.next();
                System.out.print("Ship length (in meters): ");
                double shipLength = Scanner.nextDouble();
                Scanner.nextLine();
                System.out.print("Cruise Type: ");
                java.lang.String CruiseType = Scanner.nextLine();
                System.out.print("Passenger capacity (in meters): ");
                int passengercapacity = Scanner.nextInt();
                Scanner.nextLine(); //
                System.out.print("cruiseshipID ");
                int cruiseshipID = Scanner.nextInt();
                Scanner.nextLine(); //
                System.out.print("loadCapcity ");
                int loadCapcity = Scanner.nextInt();
                Scanner.nextLine(); //
                ships.add(new CruiseLineShip(shipName, shipLength, CruiseType, passengercapacity, cruiseshipID, loadCapcity));

            }}
        catch (Exception e){
            System.out.println(e);
        }
        finally {
            for (Ship ship : ships) {
                ship.displayDetails();
                System.out.println("-------------------------");
            }
            System.out.println("-----Search------");
            for (Ship ship : ships) {
                if(ship.getPassengerName().equals("test")){
                    System.out.println("Found");
                }

            }

        }
        Scanner.close();
    }
}
        

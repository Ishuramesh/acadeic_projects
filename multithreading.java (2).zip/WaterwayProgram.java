import java.util.ArrayList;
import java.util.Scanner;

public class WaterwayProgram {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Ship> ships = new ArrayList<>();

        try {
            for (int i = 0; i < 10; i++) {
                System.out.println("Enter details for CruiseLineShip " + (i + 1) + ":");
                System.out.print("Passenger Name: ");
                String shipName = scanner.next();
                System.out.print("Ship length (in meters): ");
                double shipLength = scanner.nextDouble();
                scanner.nextLine();
                System.out.print("Cruise Type: ");
                String cruiseType = scanner.nextLine();
                System.out.print("Passenger capacity: ");
                int passengerCapacity = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Cruise Ship ID: ");
                int cruiseShipID = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Load Capacity: ");
                int loadCapacity = scanner.nextInt();
                scanner.nextLine();

                ships.add(new CruiseLineShip(shipName, shipLength, cruiseType, passengerCapacity, cruiseShipID, loadCapacity));
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            ArrayList<Thread> threads = new ArrayList<>();

            for (final Ship ship : ships) {
                Thread thread = new Thread(() -> {
                    ship.displayDetails();
                    System.out.println("-------------------------");
                });
                threads.add(thread);
                thread.start();
            }

            for (Thread thread : threads) {
                try {
                    thread.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            System.out.println("-----Search------");
            for (Ship ship : ships) {
                if (ship.getPassengerName().equals("test")) {
                    System.out.println("Found");
                }
            }

            scanner.close();
        }
    }
}

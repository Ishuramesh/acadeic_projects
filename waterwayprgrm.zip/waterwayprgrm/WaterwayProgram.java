import java.util.ArrayList;
import java.util.Scanner;

// Base class
class Ship {
    protected String shipName;
    protected double shipLength;

    public Ship(String shipName, double shipLength) {
        this.shipName = shipName;
        this.shipLength = shipLength;
    }

    public String getShipName() {
        return shipName;
    }

    public void displayDetails() {
        System.out.println("Ship Name: " + shipName);
        System.out.println("Ship Length: " + shipLength + " meters");
    }
}

// Subclass for Cruise Line Ship
class CruiseLineShip extends Ship {
    private String cruiseType;
    private int passengerCapacity;
    private int cruiseShipID;
    private int loadCapacity;

    public CruiseLineShip(String shipName, double shipLength, String cruiseType,
                          int passengerCapacity, int cruiseShipID, int loadCapacity) {
        super(shipName, shipLength);
        this.cruiseType = cruiseType;
        this.passengerCapacity = passengerCapacity;
        this.cruiseShipID = cruiseShipID;
        this.loadCapacity = loadCapacity;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Cruise Type: " + cruiseType);
        System.out.println("Passenger Capacity: " + passengerCapacity);
        System.out.println("Cruise Ship ID: " + cruiseShipID);
        System.out.println("Load Capacity: " + loadCapacity + " tons");
    }
}

// Main program
public class WaterwayProgram {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Ship> ships = new ArrayList<>();

        for (int i = 0; i < 2; i++) {
            System.out.println("Enter details for CruiseLineShip " + (i + 1) + ":");
            System.out.print("Ship Name: ");
            String shipName = scanner.nextLine();
            System.out.print("Ship length (in meters): ");
            double shipLength = scanner.nextDouble();
            scanner.nextLine();
            System.out.print("Cruise Type: ");
            String cruiseType = scanner.nextLine();
            System.out.print("Passenger capacity: ");
            int passengerCapacity = scanner.nextInt();
            System.out.print("Cruise Ship ID: ");
            int cruiseShipID = scanner.nextInt();
            System.out.print("Load Capacity (tons): ");
            int loadCapacity = scanner.nextInt();
            scanner.nextLine(); // consume newline

            ships.add(new CruiseLineShip(shipName, shipLength, cruiseType, passengerCapacity, cruiseShipID, loadCapacity));
        }

        System.out.println("\n----- Ship Details -----");
        for (Ship ship : ships) {
            ship.displayDetails();
            System.out.println("-------------------------");
        }

        // Search feature
        System.out.println("\n----- Search Ship -----");
        System.out.print("Enter ship name to search: ");
        String searchName = scanner.nextLine();
        boolean found = false;
        for (Ship ship : ships) {
            if (ship.getShipName().equalsIgnoreCase(searchName)) {
                System.out.println("Ship found!");
                ship.displayDetails();
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Ship not found!");
        }

        scanner.close();
    }
}

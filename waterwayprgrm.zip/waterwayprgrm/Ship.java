class CruiseLineShip extends Ship {
    private int cruiseShipID;

    public CruiseLineShip(String shipName, double shipLength, String cruiseType, int passengerCapacity, int cruiseShipID) {
        super(shipName, shipLength, cruiseType, passengerCapacity);
        this.cruiseShipID = cruiseShipID;
    }

    @Override
    void displayCruiseShipID() {
        System.out.println("Cruise Ship ID: " + cruiseShipID);
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        displayCruiseShipID();
    }
}
